import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of calls:");
		int noOfCalls=sc.nextInt();
		List<Contact> contactList = Contact.prefill();
		List<Call> callList=new ArrayList<>();
		for(int i=0;i<noOfCalls;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			String[] arr = detail.split(",");
			Call call=new Call();
			Contact contact=null;
			for(Contact c : contactList)
			{
				if(c.getName().equals(arr[0]))
				{
					contact=c;
					break;
				}
			}
//			Wayne,Incoming,Local,0,00:05:35,10-07-2018
			call.setContact(contact);
			call.setType(arr[1]);
			call.setCallType(arr[2]);
			call.setCost(Double.parseDouble(arr[3]));
			SimpleDateFormat sdf1=new SimpleDateFormat("hh:mm:ss");
			call.setDuration(sdf1.parse(arr[4]));
			SimpleDateFormat sdf2=new SimpleDateFormat("dd-MM-yyyy");
			call.setDate(sdf2.parse(arr[5]));
			callList.add(call);
		}
		Map<String, Integer> result = Call.monthWiseCount(callList);
		System.out.printf("%-10s %s\n","Month", "Count"); 
		for(Entry<String, Integer> e: result.entrySet())
		{
			System.out.printf("%-10s %s\n",e.getKey(), e.getValue()); 
		}
	}

}
